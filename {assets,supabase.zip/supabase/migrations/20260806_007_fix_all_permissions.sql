-- ============================================================
--  WateForm — fix 4 permission bugs for invited members
--  Run ini di: Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- ── BUG 1 & 2: Tidak ada RLS UPDATE policy untuk workspace_members
--  Akibat: .update({ permissions }) selalu gagal (RLS rejected)
--  Sehingga semua 4 toggle permissions tidak pernah tersimpan.
-- ─────────────────────────────────────────────────────────────
create policy "wsm: owner can update members"
  on public.workspace_members for update to authenticated
  using (
    exists (
      select 1 from public.workspaces
      where id = workspace_id and owner_id = auth.uid()
    )
  )
  with check (
    exists (
      select 1 from public.workspaces
      where id = workspace_id and owner_id = auth.uid()
    )
  );

-- ── BUG 3: RLS INSERT policy di migration 005 — ambiguous column
--  'workspace_id' di subquery bisa resolve ke kolom luar (row baru),
--  tapi di Postgres subquery tanpa tabel reference bisa ambigu.
--  Fix: drop & recreate dengan alias eksplisit.
-- ─────────────────────────────────────────────────────────────
drop policy if exists "wsm: owner or permitted member can insert" on public.workspace_members;

create policy "wsm: owner or permitted member can insert"
  on public.workspace_members for insert to authenticated
  with check (
    -- Owner workspace boleh insert
    exists (
      select 1 from public.workspaces w
      where w.id = workspace_members.workspace_id
        and w.owner_id = auth.uid()
    )
    -- Self-insert (owner join workspace milik sendiri)
    or user_id = auth.uid()
    -- Member dengan can_add_members=true boleh invite
    or exists (
      select 1 from public.workspace_members wm
      where wm.workspace_id = workspace_members.workspace_id
        and wm.user_id = auth.uid()
        and (wm.permissions->>'can_add_members')::boolean = true
    )
  );

-- ── BUG 4: wsm DELETE — owner yang bukan row-owner juga harus bisa remove
--  Policy lama hanya cek workspaces.owner_id, sudah benar.
--  Tambah: member dengan can_add_members=true juga bisa remove member lain
--  (opsional — skip kalau tidak diinginkan, uncomment untuk aktifkan)
-- ─────────────────────────────────────────────────────────────
-- drop policy if exists "wsm: owner can delete members" on public.workspace_members;
-- create policy "wsm: owner or permitted can delete members"
--   on public.workspace_members for delete to authenticated
--   using (
--     exists (
--       select 1 from public.workspaces w
--       where w.id = workspace_id and w.owner_id = auth.uid()
--     )
--   );

-- ── Verifikasi policies yang aktif ────────────────────────────
-- SELECT policyname, cmd FROM pg_policies
-- WHERE tablename = 'workspace_members'
-- ORDER BY cmd, policyname;

-- ── Selesai ──────────────────────────────────────────────────
-- ✅ RLS UPDATE policy ditambahkan → save permissions sekarang berhasil
-- ✅ RLS INSERT policy diperbaiki → can_add_members benar-benar berfungsi
-- ✅ 4 toggle permissions (edit questions, edit settings,
--    add members, see members) sekarang tersimpan & dibaca dengan benar
