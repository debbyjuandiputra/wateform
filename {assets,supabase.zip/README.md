# WateForm — Cara Run di Localhost

## 1. Jalankan server lokal

Pilih salah satu cara:

### Pakai Python (paling mudah, tidak perlu install apa-apa):
```bash
cd folder-wateform
python3 -m http.server 3000
```
Lalu buka: http://localhost:3000

### Pakai Node.js (npx serve):
```bash
npx serve . -p 3000
```

### Pakai VS Code:
Install extension **Live Server** → klik kanan `index.html` → Open with Live Server

---

## 2. Tambahkan localhost ke Supabase

Buka Supabase Dashboard → **Authentication → URL Configuration**:

- **Site URL**: `http://localhost:3000`
- **Redirect URLs** (klik Add URL):
  - `http://localhost:3000`
  - `http://localhost:3000/**`
  - `https://wateform.my.id` ← tetap simpan untuk production

---

## 3. Jalankan SQL migration

Di Supabase Dashboard → **SQL Editor** → jalankan file ini secara berurutan:
1. `supabase/migrations/20260805_001_profiles.sql` ← dari zip sebelumnya
2. `supabase/migrations/20260805_002_workspaces.sql`

---

## 4. Deploy Edge Function (untuk cek username)

```bash
# Install Supabase CLI dulu jika belum
npm install -g supabase

supabase login
supabase functions deploy check-username --project-ref zaaqlfxtymuafalkeftd
```

---

## Catatan

- `BASE_URL` sudah otomatis mengikuti `window.location.origin`, jadi tidak perlu ubah apapun saat pindah dari localhost ke production.
- Saat di localhost, link form akan tampil sebagai `http://localhost:3000/abc123/def456`
- Di production (`wateform.my.id`), link otomatis berubah menjadi `https://wateform.my.id/abc123/def456`
