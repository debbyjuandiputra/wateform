-- ============================================================
--  WateForm — invite member by email
--  Run this in: Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- ── RPC: look up a user's UUID from their email address ──────
--  Queries auth.users (requires security definer so that
--  the anon / authenticated role can read auth schema).
--  Returns NULL if no matching user is found.
-- ─────────────────────────────────────────────────────────────
create or replace function public.get_user_id_by_email(email_input text)
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select id
  from auth.users
  where lower(email) = lower(trim(email_input))
  limit 1;
$$;

-- Grant execute to authenticated users
grant execute on function public.get_user_id_by_email(text) to authenticated;
