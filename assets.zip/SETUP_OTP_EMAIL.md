# WateForm — Email OTP Setup (Supabase)

## STEP 1 — Aktifkan Email OTP di Supabase

1. Supabase Dashboard → **Authentication** → **Sign In / Up**
2. Di bagian **Email** → pastikan **Enable email confirmations** = ON
3. Di bagian **Email OTP** → set **OTP Expiry** = `600` (10 menit)
4. Pastikan **Confirm email** menggunakan mode **OTP**, bukan magic link

   > Cara cek: di bawah Email templates → Confirm signup,
   > pastikan template menggunakan `{{ .Token }}` bukan `{{ .ConfirmationURL }}`


## STEP 2 — Kustomisasi Email Template

Di Supabase Dashboard → **Authentication** → **Email Templates** → **Confirm signup**

Ganti seluruh isi template dengan ini:

### Subject:
```
Your WateForm verification code
```

### Body (HTML):
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Verify your WateForm account</title>
</head>
<body style="margin:0;padding:0;background:#F6FAF9;font-family:'Inter',Arial,sans-serif;-webkit-font-smoothing:antialiased;">

  <table width="100%" cellpadding="0" cellspacing="0" style="min-height:100vh;background:#F6FAF9;">
    <tr>
      <td align="center" style="padding:40px 16px;">

        <table width="100%" cellpadding="0" cellspacing="0" style="max-width:480px;">

          <!-- Logo / brand -->
          <tr>
            <td align="center" style="padding-bottom:28px;">
              <span style="font-size:22px;font-weight:700;letter-spacing:-.3px;">
                <span style="color:#0E1B18;">Wate</span><span style="color:#2BBDA4;">Form</span>
              </span>
            </td>
          </tr>

          <!-- Card -->
          <tr>
            <td style="background:#FFFFFF;border-radius:20px;border:1px solid #DCEAE6;padding:40px 36px;">

              <!-- Icon -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" style="padding-bottom:24px;">
                    <div style="width:56px;height:56px;border-radius:16px;background:#E8FAF7;display:inline-flex;align-items:center;justify-content:center;">
                      <span style="font-size:28px;">✉️</span>
                    </div>
                  </td>
                </tr>
              </table>

              <!-- Heading -->
              <h1 style="margin:0 0 10px;font-size:22px;font-weight:800;color:#0E1B18;text-align:center;letter-spacing:-.2px;">
                Verify your email
              </h1>
              <p style="margin:0 0 28px;font-size:14.5px;color:#4A5B57;line-height:1.6;text-align:center;">
                Enter this code in WateForm to confirm your account.<br>
                It expires in <strong>10 minutes</strong>.
              </p>

              <!-- OTP Code -->
              <div style="text-align:center;margin-bottom:28px;">
                <div style="
                  display:inline-block;
                  background:#F6FAF9;
                  border:2px solid #DCEAE6;
                  border-radius:14px;
                  padding:20px 36px;
                ">
                  <span style="
                    font-family:'Courier New',Courier,monospace;
                    font-size:40px;
                    font-weight:700;
                    letter-spacing:14px;
                    color:#0E1B18;
                    text-indent:14px;
                    display:block;
                  ">{{ .Token }}</span>
                </div>
              </div>

              <!-- Security note -->
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td style="
                    background:#F6FAF9;
                    border:1px solid #DCEAE6;
                    border-radius:10px;
                    padding:14px 16px;
                    font-size:13px;
                    color:#4A5B57;
                    line-height:1.5;
                  ">
                    🔒 <strong style="color:#0E1B18;">Never share this code.</strong>
                    WateForm will never ask for it via WhatsApp, Telegram, or phone.
                    If you didn't create an account, ignore this email.
                  </td>
                </tr>
              </table>

            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td align="center" style="padding-top:24px;">
              <p style="margin:0;font-size:12px;color:#9DB3AE;">
                © 2026 WateForm · wateform.com
              </p>
            </td>
          </tr>

        </table>
      </td>
    </tr>
  </table>

</body>
</html>
```


## STEP 3 — Setup SMTP (wajib untuk production)

Supabase default SMTP hanya untuk dev (limit 3 email/jam, "via supabase.io" muncul di header).
Untuk production pakai Resend — gratis 3.000 email/bulan.

### Setup Resend:
1. Buka https://resend.com → Sign up
2. **Domains** → **Add Domain** → masukkan `wateform.com` → verifikasi DNS
3. **API Keys** → **Create API Key** → salin key-nya

### Connect ke Supabase:
Di Supabase → **Project Settings** → **Auth** → **SMTP Settings**:

| Field | Value |
|-------|-------|
| Host | `smtp.resend.com` |
| Port | `465` |
| Username | `resend` |
| Password | API key dari Resend |
| Sender email | `noreply@wateform.com` |
| Sender name | `WateForm` |

Klik **Save** → **Send test email** untuk verifikasi.


## Flow lengkap yang terjadi:

```
User isi form register
       │
       ▼
signUp() → Supabase buat user (unconfirmed)
       │
       ▼
Supabase kirim email via SMTP (Resend)
dengan kode 6 digit ({{ .Token }})
       │
       ▼
Frontend tampilkan panel OTP
       │
       ▼
User masukkan 6 digit
(auto-submit saat digit ke-6 diisi)
       │
       ▼
verifyOtp({ email, token, type: "signup" })
       │
    ┌──┴──┐
  Error   OK
    │      │
    ▼      ▼
 Clear   Set email_confirmed_at
 inputs  Trigger handle_new_user
 & show  Redirect → /dashboard.html
 error
```

## Catatan penting:

- Kode hanya bisa dipakai **sekali** — setelah diverifikasi, expired otomatis
- Resend OTP (`sb().auth.resend()`) memiliki rate limit bawaan Supabase
- Email yang belum diverifikasi **tidak bisa login** — Supabase reject dengan error "Email not confirmed"
- Template `{{ .Token }}` adalah sintaks Go template bawaan Supabase, jangan diubah
