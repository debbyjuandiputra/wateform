-- ============================================================
--  WateForm — transfer_workspace_ownership function
--  Run di: Supabase Dashboard → SQL Editor → New query
-- ============================================================

create or replace function public.transfer_workspace_ownership(
  p_workspace_id uuid,
  p_new_owner_id uuid
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_current_owner uuid;
begin
  -- Verify caller is current owner
  select owner_id into v_current_owner
  from public.workspaces
  where id = p_workspace_id;

  if v_current_owner is null then
    raise exception 'Workspace not found';
  end if;

  if v_current_owner <> auth.uid() then
    raise exception 'Only the current owner can transfer ownership';
  end if;

  -- Verify new owner is a member
  if not exists (
    select 1 from public.workspace_members
    where workspace_id = p_workspace_id and user_id = p_new_owner_id
  ) then
    raise exception 'Target user is not a member of this workspace';
  end if;

  -- 1. Demote current owner to member
  update public.workspace_members
    set role = 'member'
    where workspace_id = p_workspace_id and user_id = v_current_owner;

  -- 2. Promote new owner
  update public.workspace_members
    set role = 'owner'
    where workspace_id = p_workspace_id and user_id = p_new_owner_id;

  -- 3. Update workspaces.owner_id
  update public.workspaces
    set owner_id = p_new_owner_id
    where id = p_workspace_id;
end;
$$;

-- Revoke public execute, only authenticated users
revoke execute on function public.transfer_workspace_ownership(uuid, uuid) from public;
grant execute on function public.transfer_workspace_ownership(uuid, uuid) to authenticated;
