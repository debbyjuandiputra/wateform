-- ============================================================
--  WateForm — public storage bucket for form media uploads
--  (question images/videos, image-type/video-type questions)
--  Run di: Supabase Dashboard → SQL Editor → New query
-- ============================================================

insert into storage.buckets (id, name, public, file_size_limit)
values ('form-media', 'form-media', true, 26214400) -- 25MB limit per file
on conflict (id) do update set public = true, file_size_limit = 26214400;

-- Anyone signed in (form owners/editors in the builder) can upload
create policy "form-media: authenticated can upload"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'form-media');

-- Authenticated users can update/replace their own uploads
create policy "form-media: authenticated can update own"
  on storage.objects for update to authenticated
  using (bucket_id = 'form-media' and owner = auth.uid());

-- Authenticated users can delete their own uploads
create policy "form-media: authenticated can delete own"
  on storage.objects for delete to authenticated
  using (bucket_id = 'form-media' and owner = auth.uid());

-- Public (anon) read so uploaded media renders on published forms
create policy "form-media: public can read"
  on storage.objects for select to public
  using (bucket_id = 'form-media');

-- ── Unique index for custom slugs ─────────────────────────────
-- Ensures no two forms can share the same custom slug globally
create unique index if not exists idx_forms_slug on public.forms (slug)
  where slug is not null;

-- Allow public (anon) to look up forms by slug (for custom-link URL)
-- The existing "forms: ws member can read" policy is authenticated only,
-- so we add a separate public read policy scoped to slug lookups
create policy "forms: public can read published by slug"
  on public.forms for select to anon
  using (slug is not null and is_published = true);
