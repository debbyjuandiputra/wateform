# WateForm — Supabase + hCaptcha Setup Guide

## Urutan setup (ikuti step by step)

---

## STEP 1 — Buat Supabase project

1. Buka https://supabase.com → **New project**
2. Isi: nama project (`wateform`), database password (simpan baik-baik), region (pilih `Southeast Asia`)
3. Tunggu ~2 menit sampai project aktif

---

## STEP 2 — Jalankan SQL migration

1. Di Supabase Dashboard → **SQL Editor** → **New query**
2. Copy-paste isi file `supabase/migrations/20260805_001_profiles.sql`
3. Klik **Run**

Ini akan membuat:
- Tabel `public.profiles` (linked ke `auth.users`)
- RLS policies
- Trigger auto-create profile saat signup
- Fungsi `username_available()` untuk Edge Function

---

## STEP 3 — Ambil API keys

Di Supabase Dashboard → **Project Settings** → **API**:

| Key | Dipakai di |
|-----|-----------|
| Project URL | `app.js` → `SUPABASE_URL` |
| `anon` / public key | `app.js` → `SUPABASE_ANON_KEY` |
| `service_role` key | Jangan expose! Otomatis tersedia di Edge Function via `SUPABASE_SERVICE_ROLE_KEY` |

---

## STEP 4 — Setup hCaptcha

### 4a. Buat akun & site di hCaptcha
1. Buka https://www.hcaptcha.com → **Sign up** (gratis)
2. Dashboard → **Sites** → **Add Site**
   - Hostname: domain kamu (contoh: `wateform.my.id` atau `localhost` untuk dev)
   - Difficulty: **Easy** (bisa diubah kapan saja)
3. Setelah dibuat, salin **Site Key** (format: `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`)
4. Di **Settings** → salin **Secret Key**

### 4b. Enable hCaptcha di Supabase
1. Supabase Dashboard → **Authentication** → **Sign In / Up**
2. Scroll ke bagian **Bot and Abuse Protection**
3. Toggle **Enable hCaptcha protection** → ON
4. Paste **Secret Key** dari hcaptcha.com → **Save**

> Supabase sekarang akan otomatis memvalidasi token hCaptcha di setiap
> `signUp()` dan `signInWithPassword()` — kamu tidak perlu memanggil
> `hcaptcha.com/siteverify` secara manual.

---

## STEP 5 — Deploy Edge Function

### Install Supabase CLI
```bash
# macOS
brew install supabase/tap/supabase

# Windows (via scoop)
scoop bucket add supabase https://github.com/supabase/scoop-bucket.git
scoop install supabase

# atau via npm
npm install -g supabase
```

### Login & link project
```bash
supabase login
supabase link --project-ref xxxxxxxxxxxx   # ganti dengan Project ID kamu
# Project ID ada di: Project Settings → General → Reference ID
```

### Deploy
```bash
# dari folder root project (yang ada folder /supabase)
supabase functions deploy check-username --no-verify-jwt
```

`--no-verify-jwt` diperlukan karena fungsi ini dipanggil sebelum user punya session.

### Verifikasi
```bash
curl -X POST https://xxxxxxxxxxxx.supabase.co/functions/v1/check-username \
  -H "Content-Type: application/json" \
  -d '{"username": "nadia.putri"}'
# Expected: {"available": true}
```

---

## STEP 6 — Update CONFIG di app.js

Buka `assets/app.js`, ganti 3 baris di bagian `CONFIG`:

```js
const SUPABASE_URL      = "https://xxxxxxxxxxxx.supabase.co";   // ← dari Step 3
const SUPABASE_ANON_KEY = "eyJhbGciOiJ...";                     // ← dari Step 3
const HCAPTCHA_SITE_KEY = "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"; // ← dari Step 4a
```

---

## STEP 7 — Test lokal

Buka `login.html` langsung di browser (via `file://`) **tidak akan bekerja** karena CORS.
Gunakan server lokal:

```bash
# Python
python3 -m http.server 3000

# Node
npx serve .

# VS Code: install extension "Live Server" → klik "Go Live"
```

Lalu buka http://localhost:3000/login.html

**Yang perlu dicek:**
- [ ] hCaptcha widget muncul di form login & register
- [ ] Username check real-time bekerja (coba ketik username)
- [ ] Register dengan gmail.com berhasil → muncul layar "Check your email"
- [ ] Cek inbox → ada email konfirmasi dari Supabase
- [ ] Setelah konfirmasi email → login berhasil

---

## STEP 8 — Konfigurasi email Supabase (opsional tapi disarankan)

Di Supabase Dashboard → **Authentication** → **Email Templates**:
- Kustomisasi template konfirmasi email dengan nama & branding WateForm
- Untuk production: sambungkan SMTP sendiri via **Project Settings → Auth → SMTP Settings**
  (Resend.com gratis 3000 email/bulan — direkomendasikan)

---

## Checklist sebelum production

- [ ] SQL migration dijalankan
- [ ] hCaptcha Secret Key dipaste di Supabase Auth settings
- [ ] Edge Function `check-username` ter-deploy
- [ ] `app.js` CONFIG diisi dengan key yang benar
- [ ] hCaptcha site key didaftarkan untuk domain production
- [ ] Email confirmation template dikustomisasi
- [ ] SMTP custom disambungkan (bukan Supabase default untuk >100 user/hari)
- [ ] Environment variables tidak di-commit ke Git (tambahkan `.env` ke `.gitignore`)

---

## Struktur file

```
wateform/
├── index.html
├── login.html
├── assets/
│   ├── app.js          ← Supabase + hCaptcha logic
│   ├── style.css
│   └── logo.webp
└── supabase/
    ├── functions/
    │   └── check-username/
    │       └── index.ts   ← Edge Function
    └── migrations/
        └── 20260805_001_profiles.sql
```

---

## Cara kerja validasi hCaptcha (ringkasan)

```
Browser                    Supabase Auth         hCaptcha
  │                             │                    │
  │── user selesaikan widget ──►│                    │
  │◄── captchaToken ────────────│                    │
  │                             │                    │
  │── signUp({ captchaToken })─►│                    │
  │                             │── verify token ───►│
  │                             │◄── valid/invalid ──│
  │                             │                    │
  │◄── success / error ─────────│                    │
```

Token hanya valid sekali dan expire dalam beberapa menit.
Supabase menolak request tanpa token valid jika hCaptcha diaktifkan.
