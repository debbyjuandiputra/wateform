-- ============================================================
--  WateForm — fix member list tidak tampil
--  Run ini di: Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- ── Pastikan FK workspace_members.user_id → profiles.id ada ─
--  Tanpa ini, Supabase PostgREST tidak bisa resolve
--  .select("*, profiles(...)") dari workspace_members.
--  FK ke auth.users sudah ada; kita tambah FK ke profiles juga.
-- ─────────────────────────────────────────────────────────────

-- Cek dulu apakah FK sudah ada sebelum tambah
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'workspace_members_user_id_profiles_fkey'
      AND table_name = 'workspace_members'
  ) THEN
    ALTER TABLE public.workspace_members
      ADD CONSTRAINT workspace_members_user_id_profiles_fkey
      FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;
    RAISE NOTICE 'FK added: workspace_members → profiles';
  ELSE
    RAISE NOTICE 'FK sudah ada, skip.';
  END IF;
END$$;


-- ── Pastikan kolom permissions ada (kalau migration 005 belum dirun) ──
ALTER TABLE public.workspace_members
  ADD COLUMN IF NOT EXISTS permissions jsonb NOT NULL DEFAULT '{
    "can_edit_questions": true,
    "can_edit_settings": true,
    "can_add_members": false,
    "can_see_members": false
  }'::jsonb;


-- ── Verifikasi: lihat semua member di workspace kamu ─────────
--  Jalankan SELECT ini untuk memastikan data ada di DB:
-- ─────────────────────────────────────────────────────────────
-- SELECT wm.workspace_id, wm.user_id, wm.role, p.full_name, p.username
-- FROM workspace_members wm
-- JOIN profiles p ON p.id = wm.user_id
-- ORDER BY wm.joined_at;


-- ── Selesai ──────────────────────────────────────────────────
-- ✅ FK workspace_members → profiles ditambahkan
-- ✅ Supabase PostgREST join .select("*, profiles(...)") akan bekerja
-- ✅ Kolom permissions tersedia
