-- ============================================================
--  WateForm — member permissions
--  Run ini di: Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- ── Tambah kolom permissions ke workspace_members ─────────────
--  JSONB: { can_edit_questions, can_edit_settings,
--            can_add_members, can_see_members }
--  Default: edit_questions=true, edit_settings=true,
--           add_members=false, see_members=false
-- ─────────────────────────────────────────────────────────────
alter table public.workspace_members
  add column if not exists permissions jsonb not null default '{
    "can_edit_questions": true,
    "can_edit_settings": true,
    "can_add_members": false,
    "can_see_members": false
  }'::jsonb;

-- ── Backfill: set permissions untuk semua member yang ada ─────
--  Owner tidak perlu permissions (diabaikan di frontend), tapi
--  kita set juga agar konsisten di DB.
-- ─────────────────────────────────────────────────────────────
update public.workspace_members
set permissions = '{
  "can_edit_questions": true,
  "can_edit_settings": true,
  "can_add_members": false,
  "can_see_members": false
}'::jsonb
where permissions is null
   or permissions = '{}'::jsonb;

-- ── Update RLS policy: can_add_members check ─────────────────
--  Member yang punya can_add_members=true juga boleh insert
--  ke workspace_members (di samping owner).
-- ─────────────────────────────────────────────────────────────
drop policy if exists "wsm: owner can insert members" on public.workspace_members;

create policy "wsm: owner or permitted member can insert"
  on public.workspace_members for insert to authenticated
  with check (
    -- Owner workspace
    exists (
      select 1 from public.workspaces
      where id = workspace_id and owner_id = auth.uid()
    )
    -- Self-insert (owner join their own ws)
    or user_id = auth.uid()
    -- Member dengan can_add_members=true
    or exists (
      select 1 from public.workspace_members wm
      where wm.workspace_id = workspace_id
        and wm.user_id = auth.uid()
        and (wm.permissions->>'can_add_members')::boolean = true
    )
  );

-- ── Selesai ──────────────────────────────────────────────────
-- ✅ workspace_members.permissions JSONB tersedia
-- ✅ Default: edit_questions=on, edit_settings=on, add_members=off, see_members=off
-- ✅ RLS updated: member dengan can_add_members=true bisa invite
