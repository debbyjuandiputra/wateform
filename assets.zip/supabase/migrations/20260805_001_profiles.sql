-- ============================================================
--  WateForm — initial schema
--  Run this in: Supabase Dashboard → SQL Editor → New query
-- ============================================================

-- ── 1. profiles ─────────────────────────────────────────────
--  Extends auth.users (one row per registered user).
--  Keyed by auth.users.id (UUID).
-- ────────────────────────────────────────────────────────────
create table if not exists public.profiles (
  id            uuid        primary key references auth.users(id) on delete cascade,
  full_name     text        not null,
  username      text        not null,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),

  -- username: 3–20 chars, only letters / digits / underscore / dot
  constraint username_format check (username ~ '^[a-zA-Z0-9_.]{3,20}$'),
  constraint username_unique unique (username)
);

-- Keep updated_at fresh automatically
create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_profiles_updated_at on public.profiles;
create trigger trg_profiles_updated_at
  before update on public.profiles
  for each row execute procedure public.set_updated_at();


-- ── 2. Row-Level Security ────────────────────────────────────
alter table public.profiles enable row level security;

-- Anyone authenticated can read any profile (needed for workspace invite-by-username)
create policy "profiles: authenticated users can read all"
  on public.profiles for select
  to authenticated
  using (true);

-- A user can only insert their own profile row
create policy "profiles: user inserts own row"
  on public.profiles for insert
  to authenticated
  with check (id = auth.uid());

-- A user can only update their own profile row
create policy "profiles: user updates own row"
  on public.profiles for update
  to authenticated
  using (id = auth.uid())
  with check (id = auth.uid());

-- No direct deletes — handled via auth.users cascade
create policy "profiles: no direct delete"
  on public.profiles for delete
  to authenticated
  using (false);


-- ── 3. Auto-create profile on sign-up ───────────────────────
--  Supabase fires auth.users insert → this trigger creates the
--  matching profiles row using metadata passed at signUp().
--  Required metadata keys: full_name, username
-- ────────────────────────────────────────────────────────────
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer as $$
begin
  insert into public.profiles (id, full_name, username)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', ''),
    coalesce(new.raw_user_meta_data->>'username',  '')
  );
  return new;
end;
$$;

drop trigger if exists trg_create_profile_on_signup on auth.users;
create trigger trg_create_profile_on_signup
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


-- ── 4. Helper: public username availability check ───────────
--  Called by the Edge Function (check-username).
--  Returns true if the username is still free.
-- ────────────────────────────────────────────────────────────
create or replace function public.username_available(uname text)
returns boolean language sql stable security definer as $$
  select not exists (
    select 1 from public.profiles where lower(username) = lower(uname)
  );
$$;


-- ── 5. Indexes ───────────────────────────────────────────────
create index if not exists idx_profiles_username_lower
  on public.profiles (lower(username));

create index if not exists idx_profiles_created_at
  on public.profiles (created_at desc);
