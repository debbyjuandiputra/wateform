-- ============================================================
--  WateForm — workspaces, forms, responses
--  Run AFTER 20260805_001_profiles.sql
-- ============================================================

-- ── Helper: generate random 6-char ID ───────────────────────
create or replace function public.gen_short_id()
returns text language plpgsql as $$
declare
  chars text := 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  result text := '';
  i int;
begin
  for i in 1..6 loop
    result := result || substr(chars, floor(random() * length(chars) + 1)::int, 1);
  end loop;
  return result;
end;
$$;

-- ── workspaces ───────────────────────────────────────────────
create table if not exists public.workspaces (
  id          uuid        primary key default gen_random_uuid(),
  short_id    text        not null unique,
  name        text        not null,
  description text,
  owner_id    uuid        not null references auth.users(id) on delete cascade,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  constraint workspace_name_len check (char_length(name) between 1 and 80)
);

-- Auto-set short_id
create or replace function public.set_workspace_short_id()
returns trigger language plpgsql as $$
declare candidate text;
begin
  loop
    candidate := public.gen_short_id();
    exit when not exists (select 1 from public.workspaces where short_id = candidate);
  end loop;
  new.short_id := candidate;
  return new;
end;
$$;

drop trigger if exists trg_workspace_short_id on public.workspaces;
create trigger trg_workspace_short_id
  before insert on public.workspaces
  for each row when (new.short_id is null or new.short_id = '')
  execute procedure public.set_workspace_short_id();

drop trigger if exists trg_workspaces_updated_at on public.workspaces;
create trigger trg_workspaces_updated_at
  before update on public.workspaces
  for each row execute procedure public.set_updated_at();

-- ── workspace_members ────────────────────────────────────────
create table if not exists public.workspace_members (
  workspace_id uuid    not null references public.workspaces(id) on delete cascade,
  user_id      uuid    not null references auth.users(id) on delete cascade,
  role         text    not null default 'member' check (role in ('owner','member')),
  joined_at    timestamptz not null default now(),
  primary key (workspace_id, user_id)
);

-- ── forms ────────────────────────────────────────────────────
create table if not exists public.forms (
  id            uuid        primary key default gen_random_uuid(),
  short_id      text        not null unique,
  workspace_id  uuid        not null references public.workspaces(id) on delete cascade,
  created_by    uuid        not null references auth.users(id) on delete cascade,
  title         text        not null default 'Untitled Form',
  description   text,
  slug          text,         -- custom URL slug (overrides short_id)
  questions     jsonb       not null default '[]',
  settings      jsonb       not null default '{}',
  -- settings shape: { target: 'wa'|'tg'|'both', wa_number, tg_username, language, submit_label, published }
  is_published  boolean     not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create or replace function public.set_form_short_id()
returns trigger language plpgsql as $$
declare candidate text;
begin
  loop
    candidate := public.gen_short_id();
    exit when not exists (select 1 from public.forms where short_id = candidate);
  end loop;
  new.short_id := candidate;
  return new;
end;
$$;

drop trigger if exists trg_form_short_id on public.forms;
create trigger trg_form_short_id
  before insert on public.forms
  for each row when (new.short_id is null or new.short_id = '')
  execute procedure public.set_form_short_id();

drop trigger if exists trg_forms_updated_at on public.forms;
create trigger trg_forms_updated_at
  before update on public.forms
  for each row execute procedure public.set_updated_at();

-- ── responses ────────────────────────────────────────────────
create table if not exists public.responses (
  id          uuid        primary key default gen_random_uuid(),
  form_id     uuid        not null references public.forms(id) on delete cascade,
  answers     jsonb       not null default '{}',
  sent_to     text,       -- 'wa' | 'tg' | 'both'
  submitted_at timestamptz not null default now()
);

-- ── RLS ──────────────────────────────────────────────────────
alter table public.workspaces      enable row level security;
alter table public.workspace_members enable row level security;
alter table public.forms           enable row level security;
alter table public.responses       enable row level security;

-- Helper: is user a member of workspace?
create or replace function public.is_workspace_member(ws_id uuid)
returns boolean language sql stable security definer as $$
  select exists (
    select 1 from public.workspace_members
    where workspace_id = ws_id and user_id = auth.uid()
  );
$$;

-- workspaces
create policy "ws: member can read"
  on public.workspaces for select to authenticated
  using (public.is_workspace_member(id));

create policy "ws: any authenticated can create"
  on public.workspaces for insert to authenticated
  with check (owner_id = auth.uid());

create policy "ws: owner can update"
  on public.workspaces for update to authenticated
  using (owner_id = auth.uid());

create policy "ws: owner can delete"
  on public.workspaces for delete to authenticated
  using (owner_id = auth.uid());

-- workspace_members
create policy "wsm: member can read members"
  on public.workspace_members for select to authenticated
  using (public.is_workspace_member(workspace_id));

create policy "wsm: owner can insert members"
  on public.workspace_members for insert to authenticated
  with check (
    exists (select 1 from public.workspaces where id = workspace_id and owner_id = auth.uid())
    or user_id = auth.uid()  -- allow self-insert (owner joining their own ws)
  );

create policy "wsm: owner can delete members"
  on public.workspace_members for delete to authenticated
  using (
    exists (select 1 from public.workspaces where id = workspace_id and owner_id = auth.uid())
  );

-- forms
create policy "forms: ws member can read"
  on public.forms for select to authenticated
  using (public.is_workspace_member(workspace_id));

create policy "forms: ws member can create"
  on public.forms for insert to authenticated
  with check (public.is_workspace_member(workspace_id) and created_by = auth.uid());

create policy "forms: ws member can update"
  on public.forms for update to authenticated
  using (public.is_workspace_member(workspace_id));

create policy "forms: ws member can delete"
  on public.forms for delete to authenticated
  using (public.is_workspace_member(workspace_id));

-- responses (public insert for form fillers, read for ws members)
create policy "resp: ws member can read"
  on public.responses for select to authenticated
  using (
    exists (select 1 from public.forms f where f.id = form_id and public.is_workspace_member(f.workspace_id))
  );

create policy "resp: anyone can insert"
  on public.responses for insert
  with check (true);

-- ── Auto-add owner as member on ws creation ──────────────────
create or replace function public.add_owner_as_member()
returns trigger language plpgsql security definer as $$
begin
  insert into public.workspace_members (workspace_id, user_id, role)
  values (new.id, new.owner_id, 'owner');
  return new;
end;
$$;

drop trigger if exists trg_add_owner_member on public.workspaces;
create trigger trg_add_owner_member
  after insert on public.workspaces
  for each row execute procedure public.add_owner_as_member();

-- ── Indexes ──────────────────────────────────────────────────
create index if not exists idx_ws_short_id  on public.workspaces (short_id);
create index if not exists idx_wsm_user     on public.workspace_members (user_id);
create index if not exists idx_forms_ws     on public.forms (workspace_id);
create index if not exists idx_forms_short  on public.forms (short_id);
create index if not exists idx_resp_form    on public.responses (form_id);
