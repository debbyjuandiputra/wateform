// WateForm — shared front-end behavior
// NOTE: All data below is placeholder / mock UI only. Real auth, workspaces,
// forms and responses are meant to be backed by Supabase (tables + auth +
// row-level security) — see comments near the auth forms for the fields
// this UI expects the backend to accept.

(function () {
  const root = document.documentElement;
  const toggleBtns = document.querySelectorAll('[data-theme-toggle]');

  function setTheme(theme) {
    if (theme === 'dark') {
      root.setAttribute('data-theme', 'dark');
    } else {
      root.removeAttribute('data-theme');
    }
    toggleBtns.forEach((btn) => {
      btn.setAttribute('aria-pressed', theme === 'dark');
    });
  }

  // Default: respect system preference for this session only (no storage).
  const prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
  setTheme(prefersDark ? 'dark' : 'light');

  toggleBtns.forEach((btn) => {
    btn.addEventListener('click', () => {
      const isDark = root.getAttribute('data-theme') === 'dark';
      setTheme(isDark ? 'light' : 'dark');
    });
  });

  // ---- Auth tabs (login.html) ----
  const tabs = document.querySelectorAll('.auth-tab[data-tab]');
  const panels = document.querySelectorAll('[data-panel]');
  tabs.forEach((tab) => {
    tab.addEventListener('click', () => {
      tabs.forEach((t) => t.classList.remove('active'));
      panels.forEach((p) => p.style.display = 'none');
      tab.classList.add('active');
      const target = document.querySelector(`[data-panel="${tab.dataset.tab}"]`);
      if (target) target.style.display = 'block';
      history.replaceState(null, '', tab.dataset.tab === 'register' ? '#register' : '#login');
    });
  });
  if (location.hash === '#register') {
    document.querySelector('.auth-tab[data-tab="register"]')?.click();
  }

  // ---- Register form: gmail-only email + matching passwords (client-side UX only) ----
  const registerForm = document.getElementById('register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', (e) => {
      e.preventDefault();
      let valid = true;

      const email = document.getElementById('reg-email');
      const emailField = email.closest('.field');
      const isGmail = /^[^\s@]+@gmail\.com$/i.test(email.value.trim());
      emailField.classList.toggle('invalid', !isGmail);
      if (!isGmail) valid = false;

      const pw1 = document.getElementById('reg-password');
      const pw2 = document.getElementById('reg-password-confirm');
      const pwField = pw2.closest('.field');
      const pwMatch = pw1.value.length >= 8 && pw1.value === pw2.value;
      pwField.classList.toggle('invalid', !pwMatch);
      if (!pwMatch) valid = false;

      if (!valid) return;

      // TODO (backend): supabase.auth.signUp({ email, password }) then
      // insert { full_name, username } into a `profiles` row keyed by user id.
      alert('Looks good! Hook this up to Supabase auth.signUp() to finish registration.');
    });
  }

  const loginForm = document.getElementById('login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
      e.preventDefault();
      // TODO (backend): supabase.auth.signInWithPassword({ email, password })
      alert('Hook this up to Supabase auth.signInWithPassword() to finish login.');
    });
  }
})();